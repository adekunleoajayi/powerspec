# powerspec

powerspec is a Python package for estimating wavenumber spectral density, kinetic energy spectral flux and spectral coherence of two-dimensional oceanic dataset such as SSH, vorticity.
